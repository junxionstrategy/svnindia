<?php
/**
 * @package WordPress
 * @subpackage ThemeWoot
 * @author ThemeWoot Team 
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */


if( ! class_exists( 'Twoot_Instagram_Handler') ) {
/**
 * Twoot_Instagram_Handler Class
 *
 * @class Twoot_Instagram_Handler
 * @version	1.0
 * @since 1.0
 * @package ThemeWoot
 * @author ThemeWoot Team 
 */
class Twoot_Instagram_Handler {

	/**
	 * Return the response of a call to wp_remote_get
	 *
	 * @param string $user_id
	 * @param string $parameters
	 */
	public function remote_get( $user_id, $parameters ) {

		$query = http_build_query($parameters);
		$url = 'https://api.instagram.com/v1/users/' . $user_id . '/media/recent/?' . $query;

		// Initialize the cURL session
	    $curl_session = curl_init();
	    	
	    // Set the URL of api call
		curl_setopt($curl_session, CURLOPT_URL, $url);		  
		    
		// Return the curl results to a variable
	    curl_setopt($curl_session, CURLOPT_RETURNTRANSFER, 1);
	    
	    // There was issues with some servers not being able to retrieve the data through https, If you have this problem set the config variable to FALSE
	    curl_setopt($curl_session, CURLOPT_SSL_VERIFYPEER, false);
		    
	    // Execute the cURL session
	    $contents = curl_exec ($curl_session);
		    
		// Close cURL session
		curl_close ($curl_session);

		return $contents;
	}


	/**
	 * Returns the json_decoded response body
	 *
	 * @param string $user_id
	 * @param string $parameters
	 */
	public function decoded_response_body( $user_id, $parameters ) {

		$response = $this->remote_get( $user_id, $parameters );

		return json_decode( $response );
	}


	/**
	 * Save Transient
	 *
	 * @param string $user_id
	 * @param string $token
	 * @param string $key
	 * @param string $cache
	 * @param string $counts
	 */
	public function save_transient( $user_id, $token, $key, $cache, $counts, $parameters=array() ) {

		if (get_transient($key)) {

			return get_option($key);

		} else {

			if(!empty($user_id) && !empty($token)) {

				$defaults = array(
					'access_token' => $token,
					'count' => $counts
				);

				$parameters = wp_parse_args($parameters, $defaults);

				$instagram_feed = $this->decoded_response_body( $user_id, $parameters );

				if( !is_wp_error( $instagram_feed ) && isset( $instagram_feed ) ) {

					if( $instagram_feed->meta->code == 200 ) {

						$instagrams = $instagram_feed->data;

						if( $cache == false ) {
							return $instagrams;
						} else {
							set_transient($key, $instagrams, $cache*60*60);
							update_option($key, $instagrams);

							return get_option($key);
						}
					}
				}
			}
		}
	}


	/**
	 * Get Recent Media
	 *
	 * @param string $user_id
	 * @param string $token
	 * @param string $key
	 * @param string $cache
	 * @param string $counts
	 */
	 public function get_recent_media( $user_id, $token, $key, $cache, $counts ) {

		$instagrams=$this->save_transient( $user_id, $token, $key, $cache, $counts, $parameters=array() );

		return $instagrams;
	 }
}
}